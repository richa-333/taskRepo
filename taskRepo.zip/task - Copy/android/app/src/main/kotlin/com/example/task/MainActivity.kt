package com.example.task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
